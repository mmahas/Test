import { Template } from './../layout/Template/template';

export default Template;

import { AddJobAndTask } from '../../page-components/AddJob/addJob';

export default AddJobAndTask;

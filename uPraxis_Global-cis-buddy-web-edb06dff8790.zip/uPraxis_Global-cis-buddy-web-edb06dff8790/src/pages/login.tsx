import { Login } from '../page-components/Auth/login';

export default Login;

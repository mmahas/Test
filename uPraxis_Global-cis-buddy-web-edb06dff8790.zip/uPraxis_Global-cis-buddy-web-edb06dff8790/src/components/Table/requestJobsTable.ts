export interface DataType {
  id: string;
  name: string;
  email: string;
  phone: number;
  requestDate: string;
  profileCompleted: boolean;
  job: string;
}

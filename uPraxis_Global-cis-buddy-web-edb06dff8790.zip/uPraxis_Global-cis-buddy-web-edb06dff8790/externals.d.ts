declare module '*.less' {
  const resource: Record<string, string>;
  export = resource;
}
